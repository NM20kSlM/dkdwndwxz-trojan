 ____ ____ ____ ____ ____ ____ ____ ____ ____ 
||d |||k |||d |||w |||n |||d |||w |||x |||z ||
||__|||__|||__|||__|||__|||__|||__|||__|||__||
|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|/__\|
dkdwndxz malware, comes included with safety and destructive, recommended to run on a virtual machine
use 800x600, can run on win7-11